package com.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortListWithLambda {
	

	public static void main(String[] args) {
		List<String> nameList = new ArrayList<>();
		nameList.add("Hari");
		nameList.add("Amar");
		nameList.add("Praveen");
		nameList.add("Shilpa");
		nameList.add("Gopal");
		nameList.add("Maheswar");
		nameList.add("Ranjita");
		nameList.add("Rajesh");
		nameList.add("Sai");
		
		System.out.println(nameList);
		
		Collections.sort(nameList,(a,b)->{return a.compareTo(b);});
		System.out.println(nameList);
		Collections.sort(nameList,(a,b)->b.compareTo(a));
		System.out.println(nameList);
		
		System.out.println(nameList.stream().count());
		System.out.println(nameList.stream().filter(a->a.toLowerCase().contains("h")).count());
		nameList.stream().filter(a->a.contains("i")).forEach(System.out::println);
	}

}
