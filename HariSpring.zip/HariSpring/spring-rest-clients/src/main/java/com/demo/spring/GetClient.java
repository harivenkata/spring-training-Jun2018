package com.demo.spring;

import org.apache.commons.codec.binary.Base64;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class GetClient {
	
	public static void main(String[] args){
		String credentials = "shantanu:welcome1";
		String encryptedCredentials=new String(Base64.encodeBase64(credentials.getBytes()));
		RestTemplate rt= new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", "application/json");
		headers.set("Authorization", "Basic "+encryptedCredentials);
		
		HttpEntity he=new HttpEntity<>(headers);
		ResponseEntity<String> resp = rt.exchange("http://localhost:8080/spring-mvc/emp/find/103", HttpMethod.GET, he,String.class);
		System.out.println(resp.getBody());
	}

}
