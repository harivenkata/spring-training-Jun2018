package com.demo.spring.dao;

import com.demo.spring.entity.Emp;

public class EmpDaoJdbcImpl implements EmpDao {

	@Override
	public String saveEmp(Emp e) {
		return "JDBC: Emp saved with ID " + e.getEmpId();
	}

}
