package com.demo.spring;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TransactionMain {

	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		EmpDao dao = (EmpDao) ctx.getBean("empDaoJdbcImpl");

		List<Emp> empList = new ArrayList<Emp>();
		empList.add(new Emp(300,"Hari","Hyderabad",50000));
		empList.add(new Emp(301,"Venkat","Hyderabad",500000));
		empList.add(new Emp(302,"Lakshmi","Hyderabad",60000));
		empList.add(new Emp(303,"Kumar","Hyderabad",55000));
		empList.add(new Emp(304,"Vaikhari","Hyderabad",150000));
		
		dao.saveAll(empList);
	}

}
