package com.demo.spring;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class JdbcMain2 {

	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		JdbcTemplate jt = (JdbcTemplate)ctx.getBean("jt");
		jt.query((conn)->{
			 PreparedStatement pst = conn.prepareStatement("Select * from emp");
			 return pst;
		},(ResultSet rs)->{
			System.out.println(rs.getInt("EMPNO") + " " + rs.getString("Name") + " " + rs.getString("ADDRESS") + " " +  rs.getDouble("SALARY"));
		});
		
		//Row Mapper Test
		
		List<Emp> empList = jt.query("select * from EMP",new RowMapper<Emp>(){

			@Override
			public Emp mapRow(ResultSet rs, int idx) throws SQLException {
				// TODO Auto-generated method stub
				return new Emp(rs.getInt("EMPNO") ,rs.getString("Name") ,rs.getString("ADDRESS") ,rs.getDouble("SALARY"));
			}
			
		});
		for(Emp e:empList){
			System.out.println(e.getEmpId()+" " + e.getName());
		}
		// ----------------
		Emp e=jt.queryForObject("Select * from emp where empno="+200, new RowMapper<Emp>(){

			@Override
			public Emp mapRow(ResultSet rs, int idx) throws SQLException {
				// TODO Auto-generated method stub
				return new Emp(rs.getInt("EMPNO") ,rs.getString("Name") ,rs.getString("ADDRESS") ,rs.getDouble("SALARY"));
			}
			
		});
		System.out.println(e.getEmpId() + " " + e.getName());
	}

}
