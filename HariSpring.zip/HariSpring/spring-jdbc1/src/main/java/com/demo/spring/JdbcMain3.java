package com.demo.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class JdbcMain3 {

	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		EmpDao dao = (EmpDao)ctx.getBean("empDaoJdbcImpl");
		/*String resp = dao.save(new Emp(202,"Amar","Hyderabad",50000));
		System.out.println(resp);*/
		System.out.println(dao.delete(202));
	}

}
