package com.demo.spring.dao;

import org.springframework.stereotype.Repository;

import com.demo.spring.entity.Emp;

@Repository("jdbc")
public class EmpDaoJdbcImpl implements EmpDao {

	@Override
	public String saveEmp(Emp e) {
		return "JDBC: Emp saved with ID " + e.getEmpId();
	}

}
