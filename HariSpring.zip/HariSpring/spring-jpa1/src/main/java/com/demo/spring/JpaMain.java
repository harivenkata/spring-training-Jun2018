package com.demo.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class JpaMain {

	public static void main(String[] args) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		EmpDao dao = (EmpDao)ctx.getBean("empDaoJpaImpl");
		
		System.out.println(dao.save(new Emp(401, "Kika", "Boston", 100000)));
		System.out.println(dao.findOne(201).toString());
		for(Emp e: dao.getAll()){
			System.out.println(e.toString());
		}
		
	}

}
