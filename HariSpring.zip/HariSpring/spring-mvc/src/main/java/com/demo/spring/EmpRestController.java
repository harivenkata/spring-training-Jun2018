package com.demo.spring;

import java.util.HashMap;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("emp")
public class EmpRestController {
	
	static HashMap<Integer, Emp> empDb=new HashMap<>();
	static{
		empDb.put(100,new Emp(100,"Hari","Hyderabad",24000));
		empDb.put(102,new Emp(102,"Venkat","Tirupati",30000));
		empDb.put(103,new Emp(103,"Lakshmi","Nellore",22000));
		empDb.put(104,new Emp(104,"Kumar","Guntur",29000));
		empDb.put(105,new Emp(105,"Amar","Kavali",45000));
		empDb.put(106,new Emp(106,"Praveen","Vijayawada",30000));
		empDb.put(107,new Emp(107,"Shilpa","Warangal",33000));
		empDb.put(108,new Emp(108,"Gopal","Machileeepatnam",67000));
		empDb.put(109,new Emp(109,"Phani","Tenali",97000));
		empDb.put(110,new Emp(110,"Sai","Beedar",12000));
		empDb.put(111,new Emp(111,"Madhav","Bangalore",90000));
		
	}
	
	//@RequestMapping(path="/find/{empid}",method=RequestMethod.GET)
	@GetMapping(path="/find/{empid}", produces={MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
		public ResponseEntity getById(@PathVariable("empid") int id){
		if(empDb.containsKey(id)){
			Emp e=empDb.get(id);
			return ResponseEntity.ok(e);
		}else
			return ResponseEntity.ok("Employee Not Found");
	}
	
	@RequestMapping(path="/save",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity saveEmp(@RequestBody Emp e){
	if(empDb.containsKey(e.getEmpId())){
		return ResponseEntity.ok("Employee already exist");
	}else{
		empDb.put(e.getEmpId(), e);
		return ResponseEntity.ok("Employee Saved successfully.");
	}
}
	

}
