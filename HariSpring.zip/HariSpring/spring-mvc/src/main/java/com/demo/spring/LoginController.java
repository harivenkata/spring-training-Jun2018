package com.demo.spring;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	
	@RequestMapping(path="/login", method=RequestMethod.GET)
	public String getLoginPage(){
		return "login";
	}

	/*@RequestMapping(path="/login", method=RequestMethod.POST)
	public ModelAndView processLogin(
			@RequestParam("username") String username,
			@RequestParam("password") String password){
		ModelAndView mv = new ModelAndView();
		if(username.equals(password)){
			mv.setViewName("success");
		}else
			mv.setViewName("failure");
		return mv;
	}*/
	
	@RequestMapping(path="/login", method=RequestMethod.POST)
	public ModelAndView processLogin(User user){
		ModelAndView mv = new ModelAndView();
		if(user.getUsername().equals(user.getPassword())){
			mv.setViewName("success");
			mv.addObject("user",user.getUsername());
		}else
			mv.setViewName("failure");
		return mv;
	}
}
