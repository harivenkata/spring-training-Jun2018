package com.demo.spring;

import javax.jms.JMSException;
import javax.jms.TextMessage;

import org.apache.activemq.Message;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class MyMessageListener {
	@JmsListener(destination="MyQueue",containerFactory="factory")
	public void getMessage(Message message) throws JMSException{
		TextMessage tx=(TextMessage) message;
		System.out.println(tx.getText());
	}
	

}
