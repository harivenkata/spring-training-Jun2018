package com.demo.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SenderClient {
	public static void main(String[] args) throws Exception{
		ApplicationContext ctx = new AnnotationConfigApplicationContext(JmsConfig.class);
		JmsSender sender=(JmsSender)ctx.getBean("jmsSender");
		for(int i=0; i<10;i++)
			sender.send("Hello Message"+i);
	}

}
