package com.demo.spring;

import java.util.Enumeration;

import javax.jms.JMSException;
import javax.jms.QueueBrowser;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.BrowserCallback;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

@Component
public class JmsReceiver {
	
	@Autowired
	JmsTemplate jt;
	
	public String receive() throws JMSException{
		TextMessage tx=(TextMessage)jt.receive();
		return tx.getText();
	}
	
	/*public int messageCount() throws JMSException{
		int count = jt.browse(new BrowserCallback<Integer>() {

			@Override
			public Integer doInJms(Session session, QueueBrowser qBrowser) throws JMSException {
				Enumeration e = qBrowser.getEnumeration();
				int count=0;
				while(e.hasMoreElements())
					count++;
				return (Integer)count;
			}
		});
		return count;
	}*/
	

}
