package com.demo.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ListenerMain {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new AnnotationConfigApplicationContext(JmsListenerConfig.class);
		Thread.sleep(Long.MAX_VALUE);
	}

}
