package com.demo.spring;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("emp")
public class EmpRestController {
	@Autowired
	EmpRepository repo;
	
	
	//@RequestMapping(path="/find/{empid}",method=RequestMethod.GET)
	@GetMapping(path="/find/{empid}", produces={MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
		public ResponseEntity getById(@PathVariable("empid") int id){
		Emp e = repo.findOne(id);
		if(e!=null){
			return ResponseEntity.ok(e);
		}else
			return ResponseEntity.ok("Employee Not Found");
	}
	
	@RequestMapping(path="/save",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity saveEmp(@RequestBody Emp e){
		Emp e1 = repo.findOne(e.getEmpId());
		if(e1!=null){
			return ResponseEntity.ok("Employee already exist");
		}else{
			repo.save(e);
			return ResponseEntity.ok("Employee Saved");
		}
}
	@GetMapping(path="/findsome", produces={MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity getSomeEmp(@RequestParam("salary") double salary){
		List<Emp> emps=repo.getSomeEmp(salary);
	
		return ResponseEntity.ok(emps);
}
	

}
